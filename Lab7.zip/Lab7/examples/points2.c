#include <stdio.h>
//gcc points2.c -o points2 -std=c99 -fno-stack-protector -z execstack -no-pie -fno-pie

void win(){
  printf("Yay, you win!\n");
}


void display(){
  char name[32];

  printf("This program now uses fgets() instead of gets() so it is now 100 percent secure!! No more shenanigans!\n");
  printf("Please enter your name to check points balance:\n");
  fgets(name, 0x32, stdin);
  printf("Sorry you do not have enough points :( \n");

}

int main(){
  display();
  return 0;
}

