#include <stdio.h>
//gcc points3.c -o points3 -std=c99 -fno-stack-protector -z execstack -no-pie -fno-pie


void display(){
  char name[50];

  printf("Please enter your name to check points balance:\n");
  printf("We have removed the win functionn so evil hackers have to find some other way. Don't even bother looking!!\n");



  fgets(name, 0x50, stdin);
  printf("Sorry you do not have enough points :( \n");

}

int main(){
  display();
  return 0;
}

