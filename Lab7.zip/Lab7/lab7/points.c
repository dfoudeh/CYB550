#include <stdio.h>

//gcc points.c -o points -std=c99 -fno-stack-protector -z execstack


int main(){

  int points = 0; // 4 bytes 
  char name[12]; 

  printf("If you have %d points you win a prize!\n", 0x127fcc54);
  printf("Please enter your name to check rewards balance:\n");

  gets(name);

  if (points == 0x127fcc54){
    printf("Congratulations, you have enough points! You win!\n");
  }

  else {
    printf("You do not have enough points :(\n");
    unsigned char *bytes = (unsigned char *)&points;
    printf("Points: %d\n", points);
    printf("%08x\n", points);
  }

}

