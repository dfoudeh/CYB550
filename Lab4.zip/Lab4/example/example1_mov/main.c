// main.c

int main(void) {
	int val = 100;	
	return 1;
}
