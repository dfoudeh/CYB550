// main.c

int main(void) {
	int a = 1;
	int b = a;	
	return 1;
}
