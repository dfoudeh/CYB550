	.file	"main.c"
	.intel_syntax noprefix
	.text
	.section	.rodata
.LC0:
	.string	"Value of a is 10"
.LC1:
	.string	"Value of a is 20"
	.text
	.globl	"main"
	.type	"main", @function
"main":
.LFB0:
	.cfi_startproc
	push	rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	mov	rbp, rsp
	.cfi_def_cfa_register 6
	sub	rsp, 16
	mov	DWORD PTR -4[rbp], 20
	cmp	DWORD PTR -4[rbp], 10
	jne	.L2
	lea	rax, .LC0[rip]
	mov	rdi, rax
	call	"puts"@PLT
	jmp	.L3
.L2:
	cmp	DWORD PTR -4[rbp], 20
	jne	.L3
	lea	rax, .LC1[rip]
	mov	rdi, rax
	call	"puts"@PLT
.L3:
	mov	eax, 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	"main", .-"main"
	.ident	"GCC: (GNU) 16.2.1 20260810"
	.section	.note.GNU-stack,"",@progbits
